# SimpleDES - the simplest wrapper wrapper for pyDES library - package init
# Homepage: https://github.com/greentracery/SimpleDES

__version__ = '1.0'

